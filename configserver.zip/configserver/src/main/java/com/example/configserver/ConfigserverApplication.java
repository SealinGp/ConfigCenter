package com.example.configserver;

import org.springframework.boot.SpringApplication;
import org.springframework.cloud.config.server.EnableConfigServer;


import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;


@SpringBootApplication
@EnableConfigServer
public class ConfigserverApplication {

	@RequestMapping("/")
	public String home() {
		return "Hello world,here is configserver";
	}
	public static void main(String[] args) {
		SpringApplication.run(ConfigserverApplication.class, args);
	}

}
